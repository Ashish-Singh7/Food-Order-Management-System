<html>
    <head>
   <title>Food Order Website</title>
   <Link rel="stylesheet" href="../css2/admin.css">
    </head>
    <body>
    <!-- Menu Section Starts -->
    <div class="menu text-center">
        <div class="wrapper">
            
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="manage-admin.php">Admin</a></li>
            <li><a href="manage-category.php">Catagory</a></li>
            <li><a href="manage-food.php">Food</a></li>
            <li><a href="manage-order.php">Order</a></li>
            
       </ul>
        </div>
       
   </div>
    <!-- Menu Section Ends -->