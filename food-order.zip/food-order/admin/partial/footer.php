  <!-- Footer Section Starts  -->
  <div class="footer">
       <div class="wrapper">
           <p class="text-center">2020 All right reserved, Food House .Developed By.Ashish Kumar Singh</p>
       </div>
    </div>
    <!-- Footer Section Ends -->


    </body>
 
</html>
