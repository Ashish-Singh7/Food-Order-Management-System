<?php include('partial/menu.php'); ?>

<div class="main-content">
  <div clas="wrapper">
     <h1> Add Admin</h1>
     <br><br>
     <form action="" method="post">
        <table class="tbl-30">
              <tr>
                  <td>full Name</td>
                  <td><input type="text" name="full_name" placeholder="Enter your name"></td>
              </tr>
              <tr>
                  <td>Username</td>
                  <td><input type="text" name="username" placeholder="Your Username"></td>
              </tr>
              <tr>
                  <td>Password</td>
                  <td><input type="password" name="password" placeholder="Your Password"></td>
              </tr>
              <tr>
                  <td colspan="2"> <input type="submit" name="submit" value="Add Admin" class="btnsecondary"></td>
              </tr>
     
        </table>

     </form>

  </div>

</div>


<?php include('partial/footer.php'); ?>

<?php 
//    Process the value from form and save it in database
//Check whether the submit button is clicked or not
if(isset($_POST['submit']))
{
    //Button clicked 
    //echo "button Clicked";

    //Get data form form
   $full_name= $_POST['full_name'];
   $username= $_POST['username'];
   $password =md5($_POST['password']);

   //SQL query to save the data into database
   $sql ="INSERT INTO tbi_admin SET
       full_name='$full_name',
       username='$username',
       password='$password'
   ";
   //Execute query and save data in database
   $res= mysqli_query($conn,$sql) or dir(mysqli_error());
}

?>