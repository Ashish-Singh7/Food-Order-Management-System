<?php include('partial/menu.php'); ?>

    <!-- Main Content Section starts -->
    <div class="main-content">
    <h1>Dashboard</h1>
        <div class="wrapper">
       
        <DIV class="col-4 text-center">
            <h1>5</h1>
</br>
            categories
        </DIV>
        <DIV class="col-4 text-center">
            <h1>5</h1>
</br>
            categories
        </DIV>
        <DIV class="col-4 text-center">
            <h1>5</h1>
</br>
            categories
        </DIV>
        <DIV class="col-4 text-center">
            <h1>5</h1>
</br>
            categories
        </DIV>
        <div class="clearfix"></div>
        
        </div>
   </div>
    <!-- Main Content Sectioin ends -->
    

  <?php include('partial/footer.php') ?>