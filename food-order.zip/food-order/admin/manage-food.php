<?php include('partial/menu.php') ?>

<div class="main-content">
    <div class="wrapper">
    <h1>Manage Food</h1>

    <br/>
    <br/>
    
      
    <!-- button to add admin -->
    <a href="#" class="btnprimary">Add food</a>
    <br/><br/>
      <table class="tbl-full">
          <tr >
              <th > Serial No</th>
              <th>Full Name</th>
              <th > Username</th>
              <th>Action</th>

          </tr>
          <tr>
              <td>1</td>
              <td>Ashish Singh</td>
              <td>AshishKrSingh</td>
              <td><a href="#" class="btnsecondary">Update Admin</a></td>
              <td><a href="#" class="btndenger">Delete Admin</a></td>

             

          </tr>
          <tr>
              <td>2</td>
              <td>Ashish Singh</td>
              <td>AshishKrSingh</td>
              <td><a href="#" class="btnsecondary">Update Admin</a></td>
              <td><a href="#" class="btndenger">Delete Admin</a></td>
          </tr>
          <tr>
              <td>3</td>
              <td>Ashish Singh</td>
              <td>AshishKrSingh</td>
              <td><a href="#" class="btnsecondary">Update Admin</a></td>
              <td><a href="#" class="btndenger">Delete Admin</a></td>

          </tr>
      </table>
    </div>
</div>

<?php include('partial  /footer.php') ?>